package br.com.fiap.enuns;

public enum CategoriaEnum {

	ACAO,
	TERROR,
	INFANTIL
}

